ThrowModel <- function(Y,shotNum,tstart,tstop){
outputModel = matrix(numeric(),nrow = 0, ncol = 2)
shotgun = numeric()
for (shotNum in shotNum) {
    Y_model <- Y[1:shotNum]
    step_project <- 0
    SIProject <- 0
    for (tproj in tstart:tstop) {
      for (wavet in tproj) {
          s <- wavet;
          DAMPD <- .5;
          z <- SynDiff(Y_model,s)
          SynInt <- unlist(z[2])
          DWave <- unlist(z[1])
          DDWave <- DWave[length(DWave)] - DWave[length(DWave)-1]
          DDWave2 <- DWave[length(DWave)-1]-DWave[length(DWave)-2]
          DDDWave <- DDWave2-DDWave
          DWLast <- DWave[length(DWave)]
          SILast <- SynInt[length(SynInt)]
          for (iter in 1:(s+tproj)) {
              step_project <- SILast + DWLast*DAMPD
              SILast <- step_project
              DWLast <- DWLast+DDWave+DDDWave
              DDWave <- .5*(DDWave+.25*DDDWave)
              SIProject <- c(SIProject,SILast)
            }
            SynInt <- c(SynInt,SIProject)
            shotgun <- c(shotgun,SynInt[length(SynInt)])
        }
      }
      LineNum <- t((shotNum+tstart):(shotNum+wavet))
      tempModel = matrix(
      c(LineNum,tstart:tstop),
      nrow=length(LineNum),
      ncol=2
      )
      outputModel <- rbind(outputModel,tempModel)
    }
    outputModel <- cbind(outputModel,shotgun)
    return(outputModel)
  }
