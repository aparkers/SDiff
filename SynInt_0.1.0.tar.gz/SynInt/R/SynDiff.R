SynDiff <- function(Y,s){

  all_SynDY<-numeric()
  step_DY<-numeric()
  DiffAvgs<-numeric()
  all_DY<-numeric()
  i <- length(Y)-2*s
  StDY <- sd(Y)
  DPN <- .000015
  for (iter in 1:i) {
    y1 <- (mean(Y[iter:(iter+s-1)]))
    y2 <- (mean(Y[(iter+s):(iter+(2*s-1))]))
    step_DY <- y2-y1
    all_DY <- c(all_DY,step_DY)
    DiffAvgs <- all_DY
  }
  i <- length(DiffAvgs)
  for (iter in 1:i) {
    step_SynDY <- (sum(DiffAvgs[1:iter]))
    all_SynDY<- c(all_SynDY,step_SynDY)
  }
  SynDY <- (all_SynDY)
  StDSynDY <- sd(SynDY)
  Csig <- (StDY/StDSynDY)-DPN*s
  DWave <- (DiffAvgs*Csig)
  SynInt <- (SynDY*Csig+mean(Y[1:s]))
  z <- list(DWave,SynInt)
  return(z)
}
